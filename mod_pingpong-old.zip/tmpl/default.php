<?php // no direct access
defined( '_JEXEC' ) or die( 'Restricted access' ); ?>
<?php 
$document = JFactory::getDocument();
 
$document->addScript('/js/pingpong.js');

echo $playground;
?>