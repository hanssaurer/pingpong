// RequestAnimFrame: a browser API for getting smooth animations
window.requestAnimFrame = (function(){
	return  window.requestAnimationFrame       || 
		window.webkitRequestAnimationFrame || 
		window.mozRequestAnimationFrame    || 
		window.oRequestAnimationFrame      || 
		window.msRequestAnimationFrame     ||  
		function( callback ){
			return window.setTimeout(callback, 1000 / 60);
		};
})();

window.cancelRequestAnimFrame = ( function() {
	return window.cancelAnimationFrame          ||
		window.webkitCancelRequestAnimationFrame    ||
		window.mozCancelRequestAnimationFrame       ||
		window.oCancelRequestAnimationFrame     ||
		window.msCancelRequestAnimationFrame        ||
		clearTimeout
} )();

var canvas = document.getElementById("canvas");
var rect = canvas.getBoundingClientRect();
canvas.addEventListener("mousemove", trackPosition, true);
canvas.addEventListener("mousedown", btnClick, true);
window.onload = init;
var ctx = canvas.getContext("2d"); // Create canvas context

var rightDiv = document.getElementById("playground");

var W, H;
var ball = {};
var paddles = [2];
var mouse = {};
var points = 0;


// Start Button object
startBtn = {
	w: 100,
	h: 50,
    startText: "Start",
	
	draw: function() {
		ctx.strokeStyle = "white";
		ctx.lineWidth = "2";
		ctx.strokeRect(this.x, this.y, this.w, this.h);
		
		ctx.font = "18px Arial, sans-serif";
		ctx.textAlign = "center";
		ctx.textBaseline = "middle";
		ctx.fillStyle = "yellow";
		ctx.fillText(this.startText, this.x + this.w/2, this.y + this.h/2 );
	}
};

function init() {

W = rightDiv.clientWidth; // div's width 
H = rightDiv.clientHeight; // div's height	
canvas.width = W; 
canvas.height = H;
ctx.fillRect(0, 0, W, H);	
startBtn.x = W/2 - 50,
startBtn.y = H/2 - 25,

startBtn.draw();

paddles.push(new sidePaddle("left")); 
paddles.push(new sidePaddle("right"));

}


function btnClick(e) {

	// Click start button
	if(e.offsetX >= startBtn.x && e.offsetX <= startBtn.x + startBtn.w) {
		ball.x = 20;
		ball.y = 20;
		points = 0;
		ball.vx = 4;
		ball.vy = 8;

		animloop();
	}
}

 ball = { x: 50, y: 50, r: 15, c: "yellow", vx: 3, vy: 3,
// Function for drawing ball on canvas
draw: function() {
    ctx.beginPath();
    ctx.fillStyle = this.c;
    ctx.arc(this.x, this.y, this.r, 0, Math.PI*2, false);
    ctx.fill();
	update();
    }
};

function draw() {
	paintCanvas();
	for(var i = 0; i < paddles.length; i++) {
		p = paddles[i];
		
		ctx.fillStyle = "white";
		ctx.fillRect(p.x, p.y, p.w, p.h);
	}
	
	ball.draw();
}


function trackPosition(e) {
    mouse.x = e.pageX-rect.left;
	mouse.y = e.pageY-rect.top; 
}
	

function sidePaddle(pos) { 
    // Height and width 
    this.h = 150; 
	this.w = 5;
    // Paddle's position
    this.y = H/2 - this.h/2;
    if (pos == "left") {
	    this.x = 0 ;
	}
    else {
    	this.x = W - this.w;
	}
}

// Function to paint canvas 
function paintCanvas() {
    ctx.fillStyle = "black"; 
	ctx.fillRect(0, 0, W, H); 
}


// Function for running the whole animation
function animloop() {
	init = requestAnimFrame(animloop);
	draw();
}

function update() { 
    // Move the ball 
    ball.x = ball.x + ball.vx; 
    ball.y = ball.y + ball.vy; 
	
	// Move the paddles on mouse move
	if(mouse.x && mouse.y) {
		for(var i = 1; i < paddles.length; i++) {
			p = paddles[i];
			p.y = mouse.y - p.h/2;
		}		
	}

	//Check for collission with paddles
	if (horizontalCollide(paddles[1]) || horizontalCollide(paddles[2])) {
		collideAction();
	} 
	else{
		// Collide with walls
		// if gap < paddles.width -> over!
		if(ball.x + ball.r > W - paddles[2].w) {
			ball.x = W - ball.r;
			gameOver();
		} 
		
		else if(ball.x - ball.r < paddles[1].w) {
			ball.x = ball.r;
			gameOver();
		}
	
	//  Version for bouncing from top and bottom	
		if(ball.y + ball.r > H) {
			ball.vy = -ball.vy;
			ball.y = H - ball.r;
		}
		else if(ball.y -ball.r < 0) {
			ball.vy = -ball.vy;
			ball.y = ball.r;
		}
	}
}


//Do this when collides == true
function collideAction() {
	
	ball.vx = -ball.vx;
	points++;
	increaseSpd();
	
}

// Function to increase speed after every 4 points
function increaseSpd() {
	if(points % 4 == 0) {
		if(Math.abs(ball.vx) < 15) {
			ball.vx += (ball.vx < 0) ? -1 : 1;
			ball.vy += (ball.vy < 0) ? -1 : 1;
		}
	}
}


//Function to check collision between ball and one of
//the paddles
function collides(b, p) {
	if(b.x + b.r >= p.x && b.x - b.r <=p.x + p.w) {
		if(b.y +b.r>= (p.y - p.h) && p.y > 0){
			paddleHit = 1;
			return true;
		}
		
		else if(b.y <= p.h && p.y == 0) {
			paddleHit = 2;
			return true;
		}
		
		else return false;
	}
}


function horizontalCollide(Paddle) {

	//Horizontalen Korridor testen - für beide Seiten gleich
	if (ball.y + ball.r >= Paddle.y && ball.y - ball.r < Paddle.y + Paddle.h) {
	    //left Paddle
		if (Paddle.x == 0) {
		  return ball.x - ball.r <= Paddle.w
		}
		// right Padlle
		else {
		  return ball.x + ball.r >= Paddle.x
        }
	}
}


// Function to run when the game overs
function gameOver() {
	ctx.fillStlye = "white";
	ctx.font = "20px Arial, sans-serif";
	ctx.textAlign = "center";
	ctx.textBaseline = "middle";
	ctx.fillText("Vorbei - Du hast "+points+" Punkte!", W/2, 25 );
	
	// Stop the Animation
	cancelRequestAnimFrame(init);
	
	// Show the Start button agein
	startBtn.startText = "Noch mal";
	startBtn.draw();
}
